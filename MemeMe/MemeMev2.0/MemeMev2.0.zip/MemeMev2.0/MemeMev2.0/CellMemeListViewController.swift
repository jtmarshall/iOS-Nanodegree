//
//  CellMemeListViewController.swift
//  MemeMeV1.0
//
//  Created by Jordan  on 1/9/17.
//  Copyright © 2017 Jordan . All rights reserved.
//

import Foundation
import  UIKit

class CellMemeListViewController: UITableViewCell {
    //Attach label and image
    @IBOutlet weak var topLabelList: UILabel!
    @IBOutlet weak var bottomLabelList: UILabel!
    @IBOutlet weak var listImageView: UIImageView!
}
