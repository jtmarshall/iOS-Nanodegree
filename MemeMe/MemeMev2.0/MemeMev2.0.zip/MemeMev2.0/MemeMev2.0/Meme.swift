//
//  Meme.swift
//  MemeMeV1.0
//
//  Created by Jordan  on 1/9/17.
//  Copyright © 2017 Jordan . All rights reserved.
//

import Foundation
import UIKit
//Meme scheme!
struct Meme
{
    var top: String = ""
    var bottom: String = ""
    let image: UIImage?
    let memedImage: UIImage?
}
